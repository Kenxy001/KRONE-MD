<p align="center">
  <a href="https://www.instagram.com/__ziyxn_/"> <img src="https://github.com/c-o-d-e-xx/c-o-d-e-xx/blob/main/img/bixby1.jpeg" width="500" alt="Profile"/> </a>
</p>

<p align="center">
<strong>𝑲 𝑹 𝛩 𝑵 𝞢 – 𝑴 𝐷</strong>
</p>
<p align="center">
<a href="https://github.com/c-o-d-e-xx/WhatsBixby/stargazers"><img src="https://img.shields.io/github/stars/c-o-d-e-xx/WhatsBixby?color=black&logo=github&logoColor=black&style=for-the-badge" alt="Stars" /></a>
<a href="https://github.com/c-o-d-e-xx/WhatsBixby/network/members"> <img src="https://img.shields.io/github/forks/c-o-d-e-xx/WhatsBixby?color=black&logo=github&logoColor=black&style=for-the-badge" /></a>
<a href="https://github.com/c-o-d-e-xx/WhatsBixby/blob/master/LICENSE"> <img src="https://img.shields.io/badge/License- MIT license -blueviolet?style=for-the-badge" alt="License" /> </a>
<a href="https://www.javascript.com"> <img src="https://img.shields.io/badge/Written%20in-Javascripy-skyblue?style=for-the-badge&logo=javascript" alt="javascript" /> </a>
<a href="https://nodejs.org/en"> <img src="https://img.shields.io/badge/FRAMEWORK-nodejs-green?style=for-the-badge&logo=nodejs" alt="javascript" /> </a>
<a href="https://www.npmjs.com/package/@whiskeysockets/baileys/v/6.6.0"> <img src="https://img.shields.io/npm/v/@whiskeysockets/baileys?color=white&label=baileys&logo=javascript&logoColor=blue&style=for-the-badge" /></a>
<a href="https://github.com/c-o-d-e-xx/WhatsBixby"> <img src="https://img.shields.io/github/repo-size/c-o-d-e-xx/WhatsBixby?color=skyblue&logo=github&logoColor=blue&style=for-the-badge" /></a>
<a href="https://github.com/c-o-d-e-xx/WhatsBixby/commits/master"> <img src="https://img.shields.io/github/last-commit/c-o-d-e-xx/WhatsBixby?color=black&logo=github&logoColor=black&style=for-the-badge&branch=master" /></a>
</p>
<br><br><br>

### What is KRONE_MD?

KRONE-MD is a multi-device WhatsApp bot that is built to exercise various features. It's built using JavaScript and Node.js framework, primarily leveraging the `@whiskeysockets/baileys` package. With an on going tests to make it realistic using Modern Ai features.

### Scan Qr

[![QR CODE](https://img.shields.io/badge/Scan_qr_code-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black)](https://codexnet.xyz/qr-code)

### Deploy

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?name=whatsbixby&repository=c-o-d-e-xx%2FWhatsBixby&branch=master&builder=dockerfile&dockerfile=.%2Flib%2FDockerfile&instance_type=free&env%5BSESSION_ID%5D=)

[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/c-o-d-e-xx/WhatsBixby)

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/c-o-d-e-xx/WhatsBixby)

[![Deploy to Railway](https://railway.app/button.svg)](https://railway.app/new/template/Qe0zMt)


### Donate

<a href="https://www.buymeacoffee.com/ziyankp" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-violet.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" ></a>

### ⚠️ Warning! 
```
Due to Use of WhatsApp Bot; Your WhatsApp account might get banned.
You,re responsible for any actions or charges laid on you for using this bot. 
KRONE-TECH officials has NO hand in it since its an open source project,
By using KRONE-MD whatsApp Bot you have accepted these Policies
```
